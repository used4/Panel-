<!-- index.php -->
<?php 
include ('includes/header.php');

$table_name = 'macl';
$page_name = 'mac_length';
$data = ['lenth' => '12'];

$db->insertIfEmpty($table_name, $data);

$res = $db->select($table_name, '*', '', '');

if(isset($_POST['submit'])){
    unset($_POST['submit']);
    $updateData = $_POST;
    $db->update($table_name, $updateData, 'id = :id',[':id' => 1]);
    echo "<script>window.location.href='". $page_name.".php'</script>";
}


?>
<!-- Form Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h2 class="mb-4">Mac Address length</h6>
                    <form method="post">
                        <select class="form-select mb-3" id="lenth" name="lenth">
                            <option value="4" <?=$res[0]['lenth']=='4'?'selected':'' ?>>XX:XX 4</option>
							<option value="6" <?=$res[0]['lenth']=='6'?'selected':'' ?>>XX:XX:XX 6</option>
							<option value="8" <?=$res[0]['lenth']=='8'?'selected':'' ?>>XX:XX:XX:XX 8</option>
							<option value="10" <?=$res[0]['lenth']=='10'?'selected':'' ?>>XX:XX:XX:XX:XX 10</option>
							<option value="12" <?=$res[0]['lenth']=='12'?'selected':'' ?>>XX:XX:XX:XX:XX:XX 12</option>
							<option value="14" <?=$res[0]['lenth']=='14'?'selected':'' ?>>XX:XX:XX:XX:XX:XX:XX 14</option>
                        </select>
                        <button type="submit" name="submit" class="btn btn-primary">Update length</button>
                    </form>
            </div>
        </div>
    </div>
</div>
<!-- Form End -->

<!-- Footer Start -->
<?php include ('includes/footer.php');?>
<!-- Footer End -->
</body>

</html>