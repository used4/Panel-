<?php

$weblink = getmodsbyid('3') ?? 'https://t.me/used4';
$brandname = getmodsbyid('4') ?? '𝑼𝒏𝒌𝒏𝒐𝒘𝒏';
$visione = getmodsbyid('5') ?? 'We make modern TV simple, smooth, and personal';
$footerstatu = getmodsbyid('12') ?? 'enable';
$email = getmodsbyid('6') ?? 'lankadroid@gmail.com';
$whatsapp = getmodsbyid('7') ?? 'https://wa.me/94716474696';



?>


<!-- Modal -->
<div class="modal fade" id="confirm-delete" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: black;">
            <div class="modal-header">
                <h2 style="color: white;">Confirm</h2>
            </div>
            <div class="modal-body" style="color: white;">
                Do you really want to delete?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cancel</button>
                <a style="color: white;" class="btn btn-danger btn-ok">Delete</a>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->

<?php if ($footerstatu == 'enable'){?>
<!-- Footer Start -->
<div class="container-fluid pt-4 px-4">
    <div class="bg-secondary rounded-top p-4">
        <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
                <div class="d-flex flex-column align-items-center align-items-sm-start text-center text-sm-start">
                    <div class="d-flex align-items-end justify-content-center justify-content-sm-start w-100">
                        <h3 class="text-primary mb-0">
                            <i class="fa fa-compass"></i> <?php echo $brandname; ?>
                        </h3>
                    </div>
                    <span class="bytx mt-0 mb-0"><?php echo $visione; ?></span>
                </div>
            </div>
            <div class="col-12 col-sm-6 text-center align-items-center text-sm-end">
                <a type="button" href="<?php echo $weblink; ?>" class="btn btn-square btn-info m-2"><i class="bi bi-telegram"></i></a>
                <a type="button" href="<?php echo $whatsapp; ?>" class="btn btn-square btn-success m-2"><i class="bi bi-whatsapp"></i></a>
                <a type="button" href="mailto:<?php echo $email; ?>?subject=Hello%20from%20<?php echo $brandname; ?>&body=I%20am%20interested%20in%20your%20services." class="btn btn-square btn-warning m-2"><i class="bi bi-envelope"></i></a>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
<?php }?>


<style>
.version {
    font-size: 0.75rem;
    color: #6c757d;
    vertical-align: bottom;
    position: relative;
    top: 6px;
}

.bytx {
    font-family: "Limelight", sans-serif;
    font-size: 0.90rem;
    color: #EC2E2E;
    vertical-align: middle;
}

/* Optional: Fine-tune centering for mobile */
@media (max-width: 576px) {
  .footer-column-center {
    align-items: center !important;
    text-align: center !important;
  }
}

</style>
<!-- Footer End -->


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/chart/chart.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>

<script>
    $('#confirm-delete').on('show.bs.modal', function(e) {
        $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
    });
</script>